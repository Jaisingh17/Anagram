import webapp2

class CreateUser(webapp2.RequestHandler):
    def get(self):
        return None

    def post(self):
        return None
